#!/bin/bash

# Este script instala o IceWM a partir de um pacote .edxpkg

echo "Selecione a opção de instalação:"
echo "1) Descompactar e instalar manualmente"
echo "2) Instalar automaticamente"
read -p "Digite sua escolha (1 ou 2): " choice

case $choice in
    1)
        echo "Iniciando instalação manual..."
        echo "Descompactando icewm.edxpkg2.tar.gz..."
        sudo tar -vzxf icewm.edxpkg2.tar.gz
        
        echo "Navegue até o diretório descompactado e siga os passos:"
        echo "cd icewm.edxpkg2"
        echo "cd usr"
        echo "cd share"
        echo "sudo tar -vzxf icewm.tar.gz /usr/"
        echo "sudo rm icewm.tar.gz"
        echo ""
        echo "Lembre-se de que você precisará executar esses comandos manualmente após a descompactação."
        ;;
    2)
        echo "Iniciando instalação automática..."
        echo "Descompactando e instalando IceWM..."
        sudo tar -vzxf icewm.edxpkg.tar.gz
        cd icewm.edxpkg || { echo "Erro: Não foi possível entrar no diretório icewm.edxpkg. Abortando."; exit 1; }
        cd usr || { echo "Erro: Não foi possível entrar no diretório usr. Abortando."; exit 1; }
        cd share || { echo "Erro: Não foi possível entrar no diretório share. Abortando."; exit 1; }
        sudo tar -vzxf icewm.tar.gz /usr/ || { echo "Erro: Falha ao descompactar icewm.tar.gz para /usr/. Abortando."; exit 1; }
        sudo rm icewm.tar.gz
        echo "Instalação automática do IceWM concluída."
        ;;
    *)
        echo "Opção inválida. Por favor, execute o script novamente e escolha 1 ou 2."
        ;;
esac

exit 0
