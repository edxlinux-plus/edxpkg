#!/bin/bash

echo "Este script irá configurar e instalar o IceWM."
echo "Por favor, execute-o com cautela."
echo ""

# Opções do menu
echo "Escolha uma opção:"
echo "1) Descompactar icewm-edxpkg.tar.gz e continuar a instalação"
echo "2) Sair"
echo ""

read -p "Digite sua escolha (1 ou 2): " choice

case $choice in
    1)
        echo "Opção 1 selecionada: Descompactando e instalando..."
        echo ""

        # 1. Descompactar o arquivo icewm-edxpkg.tar.gz
        echo "1. Descompactando icewm-edxpkg.tar.gz..."
        if [ ! -f "icewm-edxpkg.tar.gz" ]; then
            echo "Erro: icewm-edxpkg.tar.gz não encontrado no diretório atual."
            echo "Certifique-se de que o arquivo está aqui antes de executar o script."
            exit 1
        fi
        sudo tar -vzxf icewm-edxpkg.tar.gz
        if [ $? -ne 0 ]; then
            echo "Erro ao descompactar icewm-edxpkg.tar.gz. Abortando."
            exit 1
        fi
        echo "Descompactação concluída."
        echo ""

        # 2. Instalar o IceWM via apt
        echo "2. Instalando IceWM via apt..."
        sudo apt update
        sudo apt install icewm -y
        if [ $? -ne 0 ]; then
            echo "Erro ao instalar IceWM via apt. Abortando."
            exit 1
        fi
        echo "IceWM instalado via apt."
        echo ""

        # Verificação se o diretório icewm-edxpkg existe após a descompactação
        if [ ! -d "icewm-edxpkg" ]; then
            echo "Erro: O diretório 'icewm-edxpkg' não foi encontrado após a descompactação."
            echo "Verifique o conteúdo do seu .tar.gz."
            exit 1
        fi

        # 3. Mudar para o diretório icewm-edxpkg
        echo "3. Entrando no diretório icewm-edxpkg..."
        cd icewm-edxpkg
        if [ $? -ne 0 ]; then
            echo "Erro ao entrar no diretório icewm-edxpkg. Abortando."
            exit 1
        fi
        echo "Dentro de icewm-edxpkg."
        echo ""

        # Os próximos passos (4, 5, 6, 7 e 8) são uma reinterpretação do seu pedido,
        # pois os comandos originais estavam um pouco confusos para o objetivo de
        # "copiar" ou "descompactar" algo de ou para /usr/share.
        #
        # Supondo que você tenha arquivos de configuração ou temas IceWM dentro de
        # icewm-edxpkg/usr/share/icewm que você deseja copiar para /usr/share/icewm.
        #
        # O comando 'cp -r /usr/share/' estava incompleto e 'tar -vzxf icewm' faria
        # sentido apenas se houvesse um arquivo 'icewm.tar.gz' dentro de 'icewm-edxpkg'
        # que precisasse ser descompactado para um local específico.
        #
        # Vou assumir que 'icewm' no seu 'tar -vzxf icewm' se referia a um tarball
        # que estava dentro do pacote icewm-edxpkg.tar.gz, e que você quer copiar
        # o conteúdo de 'usr/share' do seu pacote para o sistema.

        echo "Iniciando cópia de arquivos para /usr/share..."
        # Mudar para o diretório usr/share dentro do seu pacote descompactado
        if [ -d "usr/share" ]; then
            echo "Entrando em usr/share dentro do pacote..."
            cd usr/share
            if [ $? -ne 0 ]; then
                echo "Erro ao entrar em usr/share. Abortando."
                exit 1
            fi

            # 6. Copiar o conteúdo do diretório atual (que é icewm-edxpkg/usr/share)
            # para /usr/share no sistema.
            echo "Copiando conteúdo para /usr/share/..."
            sudo cp -rv . /usr/share/
            if [ $? -ne 0 ]; then
                echo "Erro ao copiar arquivos para /usr/share. Verifique permissões."
                exit 1
            fi
            echo "Conteúdo copiado para /usr/share/."
            echo ""

            # Voltar para o diretório raiz do pacote
            cd ../..
        else
            echo "Diretório usr/share não encontrado em icewm-edxpkg. Pulando cópia de arquivos."
        fi

        # 7. e 8. Remover icewm.tar.gz
        # Isso implica que havia um arquivo 'icewm.tar.gz' *dentro* do diretório descompactado
        # de 'icewm-edxpkg', e que ele foi usado e agora deve ser removido.
        # Se 'icewm.tar.gz' for o nome do pacote inicial que você descompactou (icewm-edxpkg.tar.gz),
        # então o comando para removê-lo seria na pasta anterior.

        # Vou assumir que você se referia ao arquivo *original* icewm-edxpkg.tar.gz.
        # Estamos no diretório onde o script foi executado.
        echo "8. Removendo o arquivo de origem icewm-edxpkg.tar.gz..."
        if [ -f "icewm-edxpkg.tar.gz" ]; then
            sudo rm icewm-edxpkg.tar.gz
            echo "Arquivo icewm-edxpkg.tar.gz removido."
        else
            echo "icewm-edxpkg.tar.gz não encontrado para remoção (pode já ter sido movido/removido)."
        fi
        echo ""

        echo "Script concluído! O IceWM e seus arquivos devem estar configurados."
        ;;
    2)
        echo "Saindo do script."
        exit 0
        ;;
    *)
        echo "Opção inválida. Por favor, digite 1 ou 2."
        ;;
esac
