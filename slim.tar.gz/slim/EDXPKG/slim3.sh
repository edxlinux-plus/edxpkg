#!/bin/bash

# Função para exibir mensagem e pedir confirmação
confirm_action() {
    read -p "Deseja executar a etapa $1? (s/n): " choice
    case "$choice" in
        s|S ) return 0 ;;
        * ) return 1 ;;
    esac
}

echo "Este script irá instalar e gerenciar o SLiM."

# Etapa 0: Instalar o SLiM via apt
if confirm_action "0: Instalar o SLiM via apt"; then
    echo "Executando: apt install slim"
    sudo apt install slim
    if [ $? -ne 0 ]; then
        echo "Erro na instalação do SLiM via apt. Saindo."
        exit 1
    fi
fi

# Etapa 1: Descompactar slim.tar.gz (se existir)
if confirm_action "1: Descompactar slim.tar.gz"; then
    if [ -f "slim.tar.gz" ]; then
        echo "Executando: sudo tar -vzxf slim.tar.gz"
        sudo tar -vzxf slim.tar.gz
        if [ $? -ne 0 ]; then
            echo "Erro ao descompactar slim.tar.gz. Verifique o arquivo."
            # Não saímos aqui, pois as próximas etapas podem não depender disso
        fi
    else
        echo "slim.tar.gz não encontrado no diretório atual. Pulando etapa de descompactação."
    fi
fi

# Etapa 2: Entrar no diretório slim (assumindo que foi criado após descompactação)
if confirm_action "2: Entrar no diretório slim"; then
    if [ -d "slim" ]; then
        echo "Executando: cd slim"
        cd slim
        if [ $? -ne 0 ]; then
            echo "Não foi possível entrar no diretório 'slim'. Saindo."
            exit 1
        fi
        CURRENT_DIR=$(pwd) # Salva o diretório atual
    else
        echo "Diretório 'slim' não encontrado. Pulando esta etapa."
    fi
fi

# Etapa 3: Entrar no diretório usr (dentro de slim, se a etapa anterior foi bem sucedida)
if confirm_action "3: Entrar no diretório usr"; then
    if [ -d "usr" ]; then
        echo "Executando: cd usr"
        cd usr
        if [ $? -ne 0 ]; then
            echo "Não foi possível entrar no diretório 'usr'. Saindo."
            exit 1
        fi
        CURRENT_DIR=$(pwd)
    else
        echo "Diretório 'usr' não encontrado. Pulando esta etapa."
    fi
fi

# Etapa 4: Entrar no diretório share (dentro de usr, se a etapa anterior foi bem sucedida)
if confirm_action "4: Entrar no diretório share"; then
    if [ -d "share" ]; then
        echo "Executando: cd share"
        cd share
        if [ $? -ne 0 ]; then
            echo "Não foi possível entrar no diretório 'share'. Saindo."
            exit 1
        fi
        CURRENT_DIR=$(pwd)
    else
        echo "Diretório 'share' não encontrado. Pulando esta etapa."
    fi
fi

# Etapa 5: Copiar slim.tar.gz para /usr/share/
# Nota: Esta etapa parece redundante se o objetivo é descompactar o SLiM.
# Geralmente, os arquivos descompactados é que seriam movidos para os locais apropriados,
# e não o arquivo compactado. Assumo que você quer copiar o .tar.gz.
if confirm_action "5: Copiar slim.tar.gz para /usr/share/"; then
    # Retorna ao diretório onde o slim.tar.gz original deveria estar (antes dos 'cd')
    # ou assume que slim.tar.gz está disponível no PATH
    # Para ser mais robusto, precisaríamos do caminho completo para slim.tar.gz
    # Vamos assumir que ele está no diretório inicial do script ou em um local conhecido.
    echo "Executando: sudo cp -r slim.tar.gz /usr/share/"
    sudo cp -r slim.tar.gz /usr/share/
    if [ $? -ne 0 ]; then
        echo "Erro ao copiar slim.tar.gz para /usr/share/. Verifique a permissão ou se o arquivo existe."
    fi
fi

# Etapa 6: Descompactar slim.tar.gz em /usr/share/
# Nota: Esta etapa só funcionará se o slim.tar.gz estiver em /usr/share/
# e se você tiver permissão para descompactar lá.
if confirm_action "6: Descompactar slim.tar.gz em /usr/share/"; then
    echo "Executando: sudo tar -vzxf /usr/share/slim.tar.gz -C /usr/share/"
    sudo tar -vzxf /usr/share/slim.tar.gz -C /usr/share/
    if [ $? -ne 0 ]; then
        echo "Erro ao descompactar slim.tar.gz em /usr/share/. Verifique o arquivo e as permissões."
    fi
fi

# Etapa 7: Remover slim.tar.gz
# Remove o arquivo original, se foi copiado. Se foi descompactado em /usr/share/,
# talvez você queira remover a cópia de lá também.
if confirm_action "7: Remover slim.tar.gz"; then
    echo "Executando: rm slim.tar.gz"
    rm slim.tar.gz
    if [ $? -ne 0 ]; then
        echo "Erro ao remover slim.tar.gz. Verifique se o arquivo existe ou as permissões."
    fi
fi

# Etapas 8 e 9: Placeholder para futuras ações com EDXPKG ou outras
if confirm_action "8: Etapa 8 (Placeholder)"; then
    echo "Executando: Ação para EDXPKG ou outra etapa."
    # Adicione aqui o comando EDXPKG que você deseja executar
fi

if confirm_action "9: Etapa 9 (Placeholder)"; then
    echo "Executando: Ação para EDXPKG ou outra etapa."
    # Adicione aqui o comando EDXPKG que você deseja executar
fi

echo "Script concluído."
