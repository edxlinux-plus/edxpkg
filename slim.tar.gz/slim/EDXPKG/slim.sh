#!/bin/bash

# Script SLiM EDXPKG para instalação e configuração

echo "Iniciando a configuração do SLiM..."

# Função para perguntar ao usuário
ask_to_execute() {
    read -p "Deseja executar a opção $1? (s/n): " choice
    case "$choice" in
        s|S ) return 0 ;;
        * ) return 1 ;;
    esac
}

# Opção 1: Instalar o SLiM via APT
echo "1. Instalando o SLiM via APT..."
if ask_to_execute "1: Instalar SLiM via APT"; then
    sudo apt install slim -y
    if [ $? -eq 0 ]; then
        echo "SLiM instalado com sucesso via APT."
    else
        echo "Erro ao instalar o SLiM via APT. Verifique sua conexão ou repositórios."
        exit 1
    fi
else
    echo "Opção 1 pulada."
fi

# As próximas opções assumem que você já tem o slim.tar.gz em algum lugar acessível
# Para este script, vamos simular que ele está no diretório onde o script é executado.
# Em um cenário real com EDXPKG, o slim.tar.gz seria parte do pacote ou pré-distribuído.

# Opção 2: Descompactar slim.tar.gz
echo "2. Descompactando slim.tar.gz..."
if ask_to_execute "2: Descompactar slim.tar.gz"; then
    if [ -f "slim.tar.gz" ]; then
        sudo tar -vzxf slim.tar.gz
        if [ $? -eq 0 ]; then
            echo "slim.tar.gz descompactado com sucesso."
        else
            echo "Erro ao descompactar slim.tar.gz."
            exit 1
        fi
    else
        echo "slim.tar.gz não encontrado no diretório atual. Pulando esta etapa."
    fi
else
    echo "Opção 2 pulada."
fi

# Opção 3: Remover slim.tar.gz (após descompactar)
echo "3. Removendo slim.tar.gz..."
if ask_to_execute "3: Remover slim.tar.gz"; then
    if [ -f "slim.tar.gz" ]; then
        rm slim.tar.gz
        if [ $? -eq 0 ]; then
            echo "slim.tar.gz removido com sucesso."
        else
            echo "Erro ao remover slim.tar.gz."
        fi
    else
        echo "slim.tar.gz não encontrado. Nada para remover."
    fi
else
    echo "Opção 3 pulada."
fi

# Opção 4: Entrar no diretório slim (assumindo que foi criado após a descompactação)
echo "4. Entrando no diretório 'slim'..."
if ask_to_execute "4: Entrar no diretório 'slim'"; then
    if [ -d "slim" ]; then
        cd slim
        if [ $? -eq 0 ]; then
            echo "Entrou no diretório 'slim'."
        else
            echo "Erro ao entrar no diretório 'slim'."
            exit 1
        fi
    else
        echo "Diretório 'slim' não encontrado. Pulando esta etapa."
    fi
else
    echo "Opção 4 pulada."
fi

# Opção 5: Entrar no diretório EDXPKG (assumindo que está dentro de 'slim')
echo "5. Entrando no diretório 'EDXPKG'..."
if ask_to_execute "5: Entrar no diretório 'EDXPKG'"; then
    if [ -d "EDXPKG" ]; then
        cd EDXPKG
        if [ $? -eq 0 ]; then
            echo "Entrou no diretório 'EDXPKG'."
        else
            echo "Erro ao entrar no diretório 'EDXPKG'."
            exit 1
        fi
    else
        echo "Diretório 'EDXPKG' não encontrado. Pulando esta etapa."
    fi
else
    echo "Opção 5 pulada."
fi

# Opção 6: Entrar no diretório usr (assumindo que está dentro de EDXPKG)
echo "6. Entrando no diretório 'usr'..."
if ask_to_execute "6: Entrar no diretório 'usr'"; then
    if [ -d "usr" ]; then
        cd usr
        if [ $? -eq 0 ]; then
            echo "Entrou no diretório 'usr'."
        else
            echo "Erro ao entrar no diretório 'usr'."
            exit 1
        fi
    else
        echo "Diretório 'usr' não encontrado. Pulando esta etapa."
    fi
else
    echo "Opção 6 pulada."
fi

# Opção 7: Entrar no diretório share (assumindo que está dentro de usr)
echo "7. Entrando no diretório 'share'..."
if ask_to_execute "7: Entrar no diretório 'share'"; then
    if [ -d "share" ]; then
        cd share
        if [ $? -eq 0 ]; then
            echo "Entrou no diretório 'share'."
        else
            echo "Erro ao entrar no diretório 'share'."
            exit 1
        fi
    else
        echo "Diretório 'share' não encontrado. Pulando esta etapa."
    fi
else
    echo "Opção 7 pulada."
fi

# Opção 8: Descompactar slim.tar.gz diretamente em /usr/share/
echo "8. Descompactando slim.tar.gz diretamente em /usr/share/..."
if ask_to_execute "8: Descompactar slim.tar.gz em /usr/share/"; then
    # Ajuste este caminho se o slim.tar.gz estiver em outro lugar
    # O caminho `../../../slim.tar.gz` assume que você navegou 3 diretórios para baixo
    # e que o slim.tar.gz original está 3 níveis acima do diretório atual.
    # Você pode precisar ajustar isso dependendo de onde o script é executado
    # e onde o slim.tar.gz está.
    if [ -f "../../../slim.tar.gz" ]; then
        sudo tar -vzxf ../../../slim.tar.gz -C /usr/share/
        if [ $? -eq 0 ]; then
            echo "slim.tar.gz descompactado com sucesso em /usr/share/."
        else
            echo "Erro ao descompactar slim.tar.gz em /usr/share/."
            exit 1
        fi
    else
        echo "slim.tar.gz não encontrado para descompactar em /usr/share/. Pulando esta etapa."
    fi
else
    echo "Opção 8 pulada."
fi

# Opção 9: Remover slim.tar.gz (após descompactar em /usr/share/)
echo "9. Removendo slim.tar.gz (novamente, se ainda existir ou for uma cópia diferente)..."
if ask_to_execute "9: Remover slim.tar.gz"; then
    # Ajuste este caminho se o slim.tar.gz estiver em outro lugar
    if [ -f "../../../slim.tar.gz" ]; then
        rm ../../../slim.tar.gz
        if [ $? -eq 0 ]; then
            echo "slim.tar.gz removido com sucesso."
        else
            echo "Erro ao remover slim.tar.gz."
        fi
    else
        echo "slim.tar.gz não encontrado para remover. Nada a fazer."
    fi
else
    echo "Opção 9 pulada."
fi

# Opção 10: Copiar /home/tj/slim/EDXPKG/usr/share/slim.tar.gz para /usr/share/
echo "10. Copiando /home/tj/slim/EDXPKG/usr/share/slim.tar.gz para /usr/share/..."
if ask_to_execute "10: Copiar slim.tar.gz para /usr/share/"; then
    SOURCE_PATH="/home/tj/slim/EDXPKG/usr/share/slim.tar.gz"
    DEST_PATH="/usr/share/"

    if [ -f "$SOURCE_PATH" ]; then
        sudo cp -r "$SOURCE_PATH" "$DEST_PATH"
        if [ $? -eq 0 ]; then
            echo "slim.tar.gz copiado com sucesso para $DEST_PATH."
        else
            echo "Erro ao copiar slim.tar.gz para $DEST_PATH."
            exit 1
        fi
    else
        echo "Arquivo $SOURCE_PATH não encontrado. Pulando esta etapa."
    fi
else
    echo "Opção 10 pulada."
fi


echo "Configuração do SLiM concluída."
echo "Lembre-se de configurar o SLiM como seu display manager padrão, se desejar."
echo "Exemplo: sudo dpkg-reconfigure slim"
